// WAP to read a price of an item. Depending upon its price display 
//cheap,average,high cost
#include<stdio.h>
int main(){
  int price;
  printf("Enter the price of the product.\n");
  scanf("%d",&price);
  if(price>=5000){
    printf("High.\n");
    }else if(price>=1500){
      printf("Average.\n");
    }
  else{
      printf("Low price.\n");
  }
  return 0;
}