//percentage of 5 subjects 80-100,60-40 C ,..
#include<stdio.h>


int main(){
  int i,n=5,subject[5],total=0,percentage;
  for(i=0;i<5;i++){
    printf("Enter marks of subjects %d(F.M.= 100).\n",i+1);
    scanf("%d",&subject[i]);
    total+=subject[i];
    }
    percentage=total/5;
    if(percentage>100){
      printf("Error.\n");
    }
    else if(percentage>=80){
      printf("grade A.\n");
    }
    else if(percentage>=60){
      printf("grade B.\n");
    }
    else if(percentage>=40){
      printf("grade C.\n");
    }
    else{
      printf("grade D.\n");
    }
    return 0;
}