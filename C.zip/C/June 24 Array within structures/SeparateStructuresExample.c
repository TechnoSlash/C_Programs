#include<stdio.h>
struct Date
{
  int dd;
  int mm;
  int yyyy;
};

int main(){

}