#include<stdio.h>
  struct student{
    int roll;
    float marks[5];
  };
int main(){
  int i,total=0;
  struct student s1;
  printf("Enter roll no of student.\n");
  scanf("%d",&s1.roll);
  for(i=0;i<5;i++){
  printf("Enter marks of subject %d: ",i+1);
  scanf("%f",&s1.marks[i]);
  total+=s1.marks[0];
  }
  printf("Total maarks= %d\n",total);
  return 0;
}