// WAP named book with its member ISBN(International standard book number),name,price The price 
// is also a structure with its member retail price(rp) and wholesale price(wp). Read the information
// for n number of books. Also compute average price of each book.
#include <stdio.h>

#define MAX_NAME_LENGTH 100

struct price {
    float retail_price;
    float wholesale_price;
};

struct book {
    int ISBN;
    char name[MAX_NAME_LENGTH];
    struct price book_price;
};

void inputBookDetails(struct book *b) {
    printf("Enter ISBN: ");
    scanf("%d", &(b->ISBN));

    printf("Enter name: ");
    scanf(" %[^\n]", b->name);

    printf("Enter retail price: ");
    scanf("%f", &(b->book_price.retail_price));

    printf("Enter wholesale price: ");
    scanf("%f", &(b->book_price.wholesale_price));
}

void displayBookDetails(struct book b) {
    printf("ISBN: %d\n", b.ISBN);
    printf("Name: %s\n", b.name);
    printf("Retail Price: %.2f\n", b.book_price.retail_price);
    printf("Wholesale Price: %.2f\n", b.book_price.wholesale_price);
}

float calculateAveragePrice(struct book *books, int n) {
    float total_price = 0.0;

    for (int i = 0; i < n; i++) {
        total_price += books[i].book_price.retail_price;
    }

    return total_price / n;
}

int main() {
    int n;

    printf("Enter the number of books: ");
    scanf("%d", &n);

    struct book books[n];

    for (int i = 0; i < n; i++) {
        printf("\nEnter details for book %d:\n", i + 1);
        inputBookDetails(&books[i]);
    }

    printf("\nBook Details:\n");

    for (int i = 0; i < n; i++) {
        printf("\nBook %d:\n", i + 1);
        displayBookDetails(books[i]);
    }

    float averagePrice = calculateAveragePrice(books, n);
    printf("\nAverage Price of each book: %.2f\n", averagePrice);

    return 0;
}

