#include<stdio.h>
  struct student{
    int roll;
    float marks[5];
  };
int main(){
  int i,total,n;
  printf("Enter the number of students.\n");
  scanf("%d",&n);
  struct student s[n];
  for(int j=0;j<n;j++){
  total=0;
  printf("Enter roll no of student %d.\n",j+1);
  scanf("%d",&s[j].roll);
  for(i=0;i<5;i++){
  printf("Enter marks of subject %d of student %d: ",i+1,j+1);
  scanf("%f",&s[j].marks[i]);
  total+=s[j].marks[i];
  }
  printf("Total marks of student %d with roll no %d is %d\n",j+1,s[j].roll,total);
  }
  return 0;
}
// nested structures seperate,embedded