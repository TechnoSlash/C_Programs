// WAP to create a structure named employee which contains the member as name and address. The address is also a structure which has
// city code and name as its member.WAP to read and display the detailed info of employee.
#include<stdio.h>
struct employee
{
  char name[25];
  struct address
  {
    int city_code;
    char city_name[25];
  }add;
};
struct employee e;
int main(){
  printf("Enter name of employee.\n");
  scanf("%s",e.name);
  printf("Enter city code and city name.\n");
  scanf("%d%s",&e.add.city_code,e.add.city_name);
  printf("Name: %s\n",e.name);
  printf("City code: %d\n",e.add.city_code);
  printf("City name: %s\n",e.add.city_name);
  return 0;
}
// Help me make this code better.