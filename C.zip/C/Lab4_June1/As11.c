//WAP to take two numbers from user and one arithmetic operator
//(+, -, *, /, %) and perform the corresponding operation of those two numbers by using switch case.
#include<stdio.h>
#include<stdlib.h>
int main()
{
  char operator;
  float a,b;
  printf("Enter two numbers.\n");
  scanf("%f%f",&a,&b);
  printf("Enter your operator.\n");
  scanf(" %c",&operator);
  switch (operator)
  {
  case '+':
  a+=b;
  break;
  case '-':
  a-=b;
  break;
  case '*':
  a*=b;
  break;
  case '/':
  a/=b;
  break;
  default:
  printf("Invalid operator.\n");
    exit(0);
  }
  printf("The output is %f.\n",a);
  return 0;
}
