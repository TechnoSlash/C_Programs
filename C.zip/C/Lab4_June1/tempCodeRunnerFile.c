else{
    printf("Invalid input.\n");
  }