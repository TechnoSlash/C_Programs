// WAP to enter the number of days of year and find whether the 
// given year is leap year or not.
#include<stdio.h>
int main(){
  int days;
  printf("Enter number of days of the year.\n");
  scanf("%d",&days);
  if(days==365){
    printf("Given year is not a leap year.\n");
  }else if(days==366){
    printf("Given year is a leap year.\n");
  }else{
    printf("Invalid input. Next time, enter either 365 or 366.\n");
  }
  return 0;
}

