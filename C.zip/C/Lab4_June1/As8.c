// 8. An organization is dealing in two items, say A and B and provides the commission on the sale of these
// items according to the following policy:
// Commission rate for item A is 5% up to a sale of Rs.2000. If the sale of A is above 2000, then
// the commission is 6% on the extra sale.
// For B, 10% up to a sale of Rs.4000, if the sale is above 4000, commission rate is 12% on extra sale. 
// Given the sales of both items, WAP to compute net commission.
#include <stdio.h>
int main() {
  float a,b,commission;
  printf("Enter the sales done for item A.\n");
  scanf("%f",&a);
  printf("Enter the sales done for item B.\n");
  scanf("%f",&b);
  a>2000?(commission=a*0.06):(commission=a*0.05);
  b>4000?(commission+=b*0.12):(commission+=b*0.10);
  printf("The net commission is %f.\n",commission);
 return 0;
}
