//10. WAP to take the option from the user for Save(S), 
//Open(O), Exit(E) and print the corresponding message 
//like “you want to open the file?” by using switch case.
#include<stdio.h>
int main(){
  char a;
  printf("Enter your action(S,O or E).\n");
  scanf("%c",&a);
  switch(a){
    case 'S':
    printf("you want to save the file?\n");
    break;
    case 'O':
    printf("you want to open the file?\n");
    break;
    case 'E':
    printf("you want to exit the file?\n");
    break;
    default:
    printf("Invalid input! Next time please enter S,O or E.\n");
    break;
  }
  return 0;
}
