// 1. Write a program to print all the numbers from 1 to 100.
#include <stdio.h>
int main() {

for(int x=1;x<=100;x++) {
  printf("%d \t", x);
}
 return 0;
}
