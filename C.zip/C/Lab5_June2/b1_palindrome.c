// WAP to take five digit numbers check if the number is Palindrome or not.
#include <stdio.h>
int main() {
  int x,y=0,rmd,i=1,num;
  printf("Enter a number\n");
  scanf("%d",&x);// 12321
  num=x;
  while(x!=0){//  t      t   t    t     t      f
    rmd=x%10;//   1      2   3    2     1
    y=y*10+rmd;// 1      12  123  1232  12321
    x/=10;//      1232   123 12   1     0
  }
  if(num==y){
    printf("%d is a palindrome number.\n",num);
  }else{
    printf("%d is not a palindrome number.\n",num);
  }
 return 0;
}