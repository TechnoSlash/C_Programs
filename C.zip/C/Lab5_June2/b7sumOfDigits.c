#include<stdio.h>
int main(){
  int x,sum,rmd,negative=0;
  printf("Enter a number.\n");
  scanf("%d",&x); //651 12  3
  if(x<0){
    x=-x;
    negative=1;
  }
  while(x>9){
    sum=0;
  while(x>0){// t   t   t   f
    rmd=x%10;// 1   5   6
    sum+=rmd;// 1   6  12
    x/=10;//    65  6  0
  }
  x=sum;
  }
  printf("sum of digits in 1 digit= %d.\n",sum);
  if(negative){
    printf("The number given was negative.\n");
  }
  return 0;
}