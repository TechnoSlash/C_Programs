//28. WAP that generate the table of values of equation Y = 2 e^(-0.1t)sin 0.5 t.(where t varies from 0 to 60)
#include <stdio.h>
#include <math.h>
int main() {
    double e = M_E,y[61],sineValue;
    int t;

    for (t = 0; t <= 60; t++) {
        sineValue = 0.5 * t;
        y[t] = 2 * pow(e, -0.1) * sin(sineValue) * t;
        printf("At t = %d, Y = %lf\n", t, y[t]);
    }
    return 0;
}