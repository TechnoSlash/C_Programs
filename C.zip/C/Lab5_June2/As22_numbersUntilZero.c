//22. WAP to read the numbers until user enter zero. And count the total numbers entered, total numbers of prime number entered and sum of
//  the prime numbers entered. The program must read at least one number.
#include<stdio.h>
 int main(){
  int x,num=0,i,prime=0,condition,sum=0;
  loop:
  printf("Enter number.\n");
  scanf("%d",&x);
  if(x==0){
    num++;
    goto done;
  }else{
    num++;
    condition=1;
    for(i=2;i<=x/2;i++){
      if(x%i==0){
        condition=0;
        goto loop;
      }
    }
    prime+=condition;
    sum+=x;
    goto loop;
  }
  done:
  printf("Total numbers entered= %d.\n",num);
  printf("Total prime numbers entered= %d.\n",prime);
  printf("Sum of prime numbers = %d.\n",sum);
  return 0;
 }