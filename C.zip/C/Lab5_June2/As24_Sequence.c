//24. WAP to compute the sum of the following series without using pow() function. 1^2 - 2^2 + 3^2 - 4^2....+(-1)^(n+1)*n^2 . where value
//  of n is entered by the user.
#include<stdio.h>
int main(){
  int sum=0,i,n;
  printf("Enter the value of n.\n");
  scanf("%d",&n);
  for(i=1;i<=n;i++){
    if(i%2==0){
      sum-=i*i;
    }else{
      sum+=i*i;
    }
  }
  printf("The sum of series till nth term is %d.\n",sum);
  return 0;
}