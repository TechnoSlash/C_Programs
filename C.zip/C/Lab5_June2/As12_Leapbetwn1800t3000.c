#include<stdio.h>
int main(){
  for (int i=1800;i<=3000;i++){
    if(i%100==0){
      if(i%400==0){
        printf("%d\t",i);
      }
    }else{
      if(i%4==0){
        printf("%d\t",i);
      }
    }
  }
  return 0;
}