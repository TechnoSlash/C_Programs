// 4. WAP to find the HCF and LCM of two given numbers.
#include <stdio.h>
int main() {
  int x,y,temp;
  printf("Enter two number\n");
  scanf("%d%d",&x,&y);
  while(x%y!=0){
    temp=y;
    y=x%y;
    x=temp;
  }
  printf("HCF= %d.\n",y);
  
 return 0;
}
