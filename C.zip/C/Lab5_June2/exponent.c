#include <stdio.h>
#include <math.h>

int main() {
    double base = 2.0;
    double exponent = 3.0;
    double result = pow(base, exponent);

    printf("%lf raised to the power of %lf is %lf\n", base, exponent, result);

    return 0;
}