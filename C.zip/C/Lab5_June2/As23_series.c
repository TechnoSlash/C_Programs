// 23. WAP to display the first 10 terms of following series.
// 1 2 5 10 17 ...
#include<stdio.h>
int main(){
  int d=1,i,n=1;
  for(i=1;i<=10;i++){
    printf("%d\t",n);
    n=n+d;
    d=d+2;
  }
  return 0;
}