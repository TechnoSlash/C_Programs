//2. WAP to print numbers from 100 to 10 which are exactly division by 11 but not by 7.
#include <stdio.h>
int main() {
  int x;
  for(x=100;x>=10;x--) {
    if(x%11==0 && x%7!=0){
      printf("%d \t",x);
    }
}
 return 0;
}
