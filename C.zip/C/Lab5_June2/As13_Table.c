//3. WAP to compute and display the table of number n given by user.
#include <stdio.h>
int main(){
  int x,i;
  printf("Enter a number\n");
  scanf("%d",&x);
  for(i=1;i<=10;i++){
    printf("%d X %d = %d\n",x,i,x*i);
  }
 return 0;
}