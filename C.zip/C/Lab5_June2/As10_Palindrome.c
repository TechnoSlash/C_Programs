//10. Write a program to find the reverse of the number entered by the user. Then check whether the reverse
//is equal to the original number. If the reverse and original numbers are equal, display a message telling
//digit = number % 10; number /= 10;
//sum += digit;
//that the number is a palindrome
#include<stdio.h>
int main(){
  int x,n,rmd,num=0;
  printf("Enter a number.\n");
  scanf("%d",&x);
  n=x;
  while(x>0){
    rmd=x%10;
    num=num*10+rmd;
    x/=10;
  }
  if(num==n){
    printf("%d is a palindrome number.\n",n);
  }else{
    printf("%d is not a palindrome number.\n",n);
  }
  return 0;
}