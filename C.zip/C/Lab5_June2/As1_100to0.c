//1. Write a program to print all the numbers from 100 to 1.
#include <stdio.h>
int main() {
  int x;
  for(x=100;x>0;x--){
    printf("%d\t",x);
  }
 return 0;
}