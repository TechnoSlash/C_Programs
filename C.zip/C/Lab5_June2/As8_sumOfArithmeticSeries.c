// 8. WAP to calculate the sum of first 10 terms of the following series using for loop 1 5 9 13 .. ..
#include <stdio.h>
int main(){
  int x=1,sum,i;
  printf("\n");
  for(i=0;i<10;i++){
    sum+=x;
    x+=4;
  }
  printf("Sum till 10th term of that series= %d.\n",sum);
 return 0;
}