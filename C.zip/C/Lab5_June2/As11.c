// 11. WAP to print your name 10 times.
#include <stdio.h>
int main(){
  for(int i=0;i<10;i++){
    printf("Riwaj Karki.\n");
  }
 return 0;
}