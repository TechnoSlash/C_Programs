//3. Write a program to print the factorial of number entered by the user. Use any loop of your choice.
#include <stdio.h>
int main() {
  int x,fac=1;
  printf("Enter a number\n");
  scanf("%d",&x);
  if(x<0){
    printf("Factorial of negative number dowesn't exist.\n");
  }else{
  for(x=x;x>0;x--) {
    fac*=x;
  }
  printf("Factorial= %d \n",fac);
  }
 return 0;
}
