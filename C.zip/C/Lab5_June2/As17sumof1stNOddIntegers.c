//17. WAP to calculate sum of first n odd integers.
#include<stdio.h>
int main(){
  int n;
  printf("Enter a number.\n");
  scanf("%d",&n);
  // for(i=0;i<n;i++){//n times
  //   sum+=j;
  //   j+=2;
  // }
  printf("The sum of first %d odd numbers is %d.\n",n,n*n);
  return 0;
}