#include<stdio.h>
int main(){
  int n,r,P,C,i,nFac=1,rFac=1,nrFac=1;
  printf("Enter n and r.\n");
  scanf("%d%d",&n,&r);
  for(i=n;i>=1;i--){
    nFac*=i;
  }
  for(i=r;i>=1;i--){
    rFac*=i;
  }
  for(i=(n-r);i>=1;i--){
    nrFac*=i;
  }
  P=nFac/rFac;
  C=nFac/(rFac*nrFac);
  printf("Permutation=%d\n",P);
  printf("Combination=%d\n",C);
  return 0;
}