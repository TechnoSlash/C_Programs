//14. WAP to find the sum of numbers between 1111 to 4444.
#include<stdio.h>
int main(){
  long int i,sum;
  for(i=1111;i<=4444;i++){
    sum+=i;
  }
  printf("The sum from 1111 to 4444 is %ld.\n",sum);
}