//9. Write a program to check whether entered number is prime number or not.
#include <stdio.h>
int main(){
  int x,i,flag=1;
  printf("Enter a number\n");
  scanf("%d",&x);
  if(x==2){
    goto output;
  }
  if(x%2==0){
    flag=0;
    goto output;
  }
  for(i=3;i<=x/2;i=i+2){
    if(x%i==0){
      flag=0;
      break;
    }
  }
  output:
  if(flag){
    printf("%d is a prime number.\n",x);
  }else{
    printf("%d is not a prime number.\n",x);
  }
 return 0;
}