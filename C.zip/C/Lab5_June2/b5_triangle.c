//5. WAP print this triangle. 
//1
//01
//101 
//0101 
//10101
#include<stdio.h>
int main(){
  int i,j,k;
  for(i=1;i<=5;i++){
    if(i%2){
      k=1;
    }else{
      k=0;
    }// I couldn't use ternery for this.
    for(j=0;j<i;j++){
      printf("%d",k);
      k==0?(k=1):(k=0);
    }
    printf("\n");
  }
  return 0;
}