//18. WAP to add first seven terms of the following series using for loop.
// 1/1!+2/2!+3/3!+...
#include<stdio.h>
int main(){
  int i,fac,sum=0;
  for(i=1;i<=7;i++){
    fac=1;
    for(i=i;i>0;i--){
      fac*=i;
    }
    sum=sum+(i/fac);
  }
  printf("Sum of series is %d.\n",sum);
  return 0;
}