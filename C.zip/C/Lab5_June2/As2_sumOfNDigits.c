#include <stdio.h>
int main() {
  int x,num;
  long int sum=0;
  printf("Enter your number\n");
  scanf("%d",&x);
  num=x;
  while(x>0){
    sum+=x;
    x--;
  }
  printf("The sum from 1 to %d is %ld.\n",num,sum);
 return 0;
}