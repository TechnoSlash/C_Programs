//3. Write a program to display all the even number from 1 to n. read n from user.
#include <stdio.h>
int main(){
  int x,i;
  printf("Enter a number.\n");
  scanf("%d",&x);
  for(i=2;i<=x;i=i+2){
    printf("%d\t",i);
  }
 return 0;
}