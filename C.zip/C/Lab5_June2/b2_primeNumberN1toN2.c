//2. WAP to find prime number between any ranges of two numbers given by user. 
// A program to print all prime numbers from n1 to n2
#include<stdio.h> 
int main()
{
int i,j,flag,n1,n2;
printf("enter n1 and n2.\n"); 
scanf("%d%d",&n1,&n2);
printf("The prime number from n1 to n2 are:\n"); 
for(i = n1 ; i <= n2 ; i++){// 2  10
for(j = 2 ; j < i/2 ; j++){
if(i%j==0){
  flag=0;
  break; 
}
else{
  flag=1;
}
}
if(flag){
  printf("%d\t ",i);
}
}
return 0;
}