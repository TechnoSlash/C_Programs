//26. WAP to find the sum of the series Sn = ∑ 1/n^2, value of n is given by the user.
#include<stdio.h>
int main(){
  int n;
  float sum,i;
  printf("Enter the value of n.\n");
  scanf("%d",&n);
    for(i=1;i<=n;i++){
      sum+=1/(i*i);
    }
  printf("%f\t",sum);
  return 0;
}