//3. WAP to print all Armstrong numbers between any range of two numbers given by user.(Hint: 13+53+33=153 i.e a3+b3+c3=abc).
#include<stdio.h>
#include<math.h>
int main(){
  long int n1,n2,i,rmd,chk,arm;
  printf("From what range of numbers do you want to check for armstrong?\n");
  scanf("%ld%ld",&n1,&n2);// 2 100
  for(i=n1;i<=n2;i++){// 2 to 100 (99 iterations)
    chk=i;//            2    3  
    arm=0;
    while(i>0){//       t    t
      rmd=i%10;//       2    3
      arm+=pow(rmd,3);//8    27
      i/=10;//          0    0
    }//                 f    f 
    if(arm==chk){//     f
      printf("%ld\t",arm);
    }
  }
  return 0;
}