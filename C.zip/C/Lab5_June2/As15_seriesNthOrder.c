//15. WAP to compute the given series of nth order.
// Y = 1 + x +x2/ 2 ! + x3/3! + x4/4!+...+xn/n!
#include<stdio.h>
#include<math.h>
int main(){
  int i,x,y=0,fac=1;
  printf("Enter the value of x.\n");
  scanf("%d",&x);
  for(i=0;i<=100;i++){
  for(i=i;i>0;i--) {
    fac*=i;
  }
    y+=pow(x,i)/fac;
  }
  return 0;
}