//25. WAP to find the terms in the given series till the value of the term is less than 1000. (1^2+2^2)/3 , (2^2+3^ 2)/4 , (32+42)/5 , ..........
#include<stdio.h>
int main(){
  float num,i;
  while(num<1000){
    for(i=1;i<=20;i++){
      num=(i*i+((i+1)*(i+1)))/(i+2);
      printf("%f\t",num);
    }
  }
  return 0;
}