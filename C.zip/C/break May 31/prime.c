//  WAP To enter a number form a user and check whether it is a 
// prime number or not.
// 2 3 5 7 11 13 17 19 23 29 31 37 41 
#include<stdio.h>
int main(){
  int n,condition=0,loops=0;
  printf("Enter a number. \n");
  scanf("%d",&n);
  for(int i=2;i<=n/2;i++){
    if(n%i==0){
      condition=1;
      break;
    }
    loops+=1;
  }
  if(condition){
    printf("%d is not a prime number.\n",n);
  }else{
    printf("%d is a prime number.\n",n);
  }
  printf("The loop was executed %d times.\n ",loops);
  return 0;
}
