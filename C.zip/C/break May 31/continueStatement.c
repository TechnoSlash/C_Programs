// Continue statement- It is used to bypass remainder of the current 
// pass through the loop
// The loop does not terminate. Instead the remaining loop 
// statements are skipped and the computation proceeds directly to 
// the next pass.
#include<stdio.h>
int main(){
  for(int i=1;i<=5;i++){
    if(i==4){
      continue;
    }
    printf("%d\t",i);
  }
  printf("We are out of the loop.\n");
  return 0;
}
