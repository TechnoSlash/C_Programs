// GOTO statement is used to alter the normal sequence of the program
// execution by unconditionally transferring control to some other 
// parts of the program.
// The goto statement transfers the control to the levelled statement
// somewhere in the current function
// syntax: goto label;
//label:
#include<stdio.h>
int main(){
  int num;
  Label:
  printf("Enter a number.\n");
  scanf("%d",&num);
  printf("%d\n",num*100);
  goto Label;
  return 0;
}