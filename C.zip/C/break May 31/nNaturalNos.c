// WAP to give the sum of n natural numbers. Use goto statement.
#include<stdio.h>
#include<stdlib.h>
int main(){
  int num,sum=0;
  printf("Enter a number.\n");
  scanf("%d",&num);
  process:
  sum+=num;
  num-=1;
  if(num==0){
    goto end;
  }else if(num<0){
    printf("you entered a negative number.\n");
    exit(0);
  }
  goto process;
  end:
  printf("sum= %d\n",sum);
  return 0;
}