// WAP to enter 2 numbers and display the HCF
// b%a==0  9%6!=0
// b=a;    b=6
// a=b%a   a=6%6
// while(b%a!=0) //9%6==3
// hcf=a//   hcf=6
// b=a//     b= 6
// a=rmd
#include<stdio.h>
int main(){
int a,b;
printf("Enter any 2 numbers.\n");
scanf("%d%d",&a,&b);// 6 9
// repeat:
while(a%b!=0){//6%9=6  9%6=3 6%3=0
  a=b;// 9 6
  b=a%b;//6 3
}
// if (a%b!=0){
//   goto repeat;
// }
printf("The hcf is %d\n",b);
return 0;
}
