//Break statement- It terminates the loop or switch statemen. As soon
//as break statement is encountered, it jumps and ends the loop or 
//switch statement and executes the statements following the loop.
// syntax break;
#include<stdio.h>
int main(){
  for(int i=1;i<=5;i++){
    if(i==4){
      break;
    }
    printf("%d\t",i);
  }
  printf("We are out of the loop.\n");
  return 0;
}
