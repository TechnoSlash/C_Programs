// exit function is a jump statement in C language, which takes an
// integer(0 or non 0) to represent different exit status
// syntax: 
// exit(0):
// It indicates sucessful exit.
// i.e. Program has been executed without any error or interrupt
// exit(1)
// It indicates failure of exit. This means that the program has 
// encountered some error or interrupt and has a abnormal termination.
#include<stdio.h>
#include<stdlib.h>
// #include<process.h>
int main(){
  int num;
  
  printf("Enter a number.\n");
  scanf("%d",&num);
  goto x;
  printf("%d\n",num*100);
  x:
  exit(0);
  return 0;
}