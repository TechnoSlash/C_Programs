// WAP to enter any character form keyboard and display whether 
//the given character is alphabet,number or other special characters
//  using goto statement.
#include<stdio.h>
#include<stdlib.h>
int main(){
  int alpha=0,number=0;
  char character;
  printf("Enter a character.\n");
  scanf("%c",&character);
  if(character<='z' && character>='a' || character<='Z' && character>='A'){
    goto alpha;
  }else if(character<='9' && character>='0'){
    goto number;
  }else{
    goto special;
  }
  alpha:
    printf("%c is a alphabet.\n",character);
    exit(0);
  number:
    printf("%c is a number.\n",character);
    exit(0);
  special:
    printf("%c is a special character.\n",character);
    exit(0);
  return 0;
}