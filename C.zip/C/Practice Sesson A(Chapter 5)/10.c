// 10. WAP to enter a character from keyboard and check whether it is alphabet or number. 
// If character is an lowercase alphabet convert it to uppercase and vice versa. 
// program should use unformatted I/O functions.
#include<stdio.h>
int main(){
  char input;
  puts("Enter your input.\n");
  gets(&input);
    if(input<='z' && input>='a'){
      input-=32;
    putchar(input);
    }
    else if(input<='Z' && input>='A'){
    input+=32;
    putchar(input);
    }else if(input<='9' && input>='0'){
      putchar(input);
    }
    getchar(); 
    return 0;
}
