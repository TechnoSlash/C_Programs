//8.WAP to find the largest among three numbers using binary minus operator.
#include<stdio.h>
int main(){
  int a,b,c;
  printf("Enter three numbers.\n");
  scanf("%d%d%d",&a,&b,&c);
  if((a-b)>0 && (a-c)>0){
    printf("%d",a);
  }else if((b-a)>0 && (b-c)>0){
    printf("%d",b);
  }else{
    printf("%d",c);
  }
  printf(" is the largest number.\n");
  return 0;
}
