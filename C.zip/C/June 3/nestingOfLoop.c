//Nesting loop feature of C that allows looping inside another loop.
// Loop inside a loop.
// Any number of loops can be defined inside another loop.
//WAP to display multiplication table from 1 to 20
#include<stdio.h>
int main(){
  int i,j;
  for(i=1;i<=10;i++){
    for(j=1;j<=20;j++){
      if((i*j)>=10 && (i*j)<100){
        printf("%d  ",i*j);
      }else if((i*j)>=100){
      printf("%d ",i*j);
      }else{
        printf("%d   ",i*j);
      }
    }
    printf("\n");
  }
  return 0;
}