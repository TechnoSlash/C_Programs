//WAP to enter a number and check whether it is strong number or not.
// 145=1!+2!+5!
#include<stdio.h>
int main(){
  int num,rem,sum=0,fac,i,m;
  printf("Enter a number.\n");
  scanf("%d",&num);//145
  m=num;
  do{
    fac=1;
    rem=num%10;//       5  4 1
    for(i=1;i<=rem;i++){//rem=5
      fac*=i;//1 2  6  24  120
    }
    sum+=fac;// 120  120+24  124+1
    num=num/10;//14
  }while(num>0);//t t f
  printf("sum= %d\n",sum);//145
  printf("num= %d\n",m);//145
  if(sum==m){
    printf("Strong number.\n");
  }else{
    printf("Not a strong number.\n");
  }
  return 0;
}