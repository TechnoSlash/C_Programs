#include<stdio.h>
int main(){
  int i=1,j;
  while(i<=3){
    j=1;
    while(j<=2){
      printf("Nepal.\n");
      j++;
    }
    i++;
  }
  return 0;
}