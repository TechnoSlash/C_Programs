// WAP to enter a number and check whether it is aa perfect number or not.
// 8  1 2 4 =7
// 6 1 2 3 = 6
// 28 1 2 4 7 14=28
#include<stdio.h>
int main(){
  int num,i,sum=0;
  printf("Enter a number.\n");
  scanf("%d",&num);//6
  for(i=1;i<num;i++){//1 2   3   4 5 6
    if(num%i==0){//    t t   t   f f
    sum+=i;//          1 1+2 3+3 
  }
  }
  if(sum==num){
    printf("Perfect number.\n");
  }else{
    printf("Not a perfect number.\n");
  }
  return 0;
}