// WAP to enter a number,calculate the sum of its digits;till the sum is a single digit.
// use nested loop.
#include<stdio.h>
int main(){
  int num,i,sum,rem;
  printf("Enter a number.\n");
  scanf("%d",&num);//651 12 3
  while(num>9){// t t f
  sum=0;
  while(num>0){// t  t    t    f
  rem=num%10;//   1  5    6
  sum+=rem;//     1  5+1  6+6
  num=num/10;//   65 6    0
  }
  num=sum;// 12  3
  }
  printf("The sum of digits is %d.\n",sum);
  return 0;
}