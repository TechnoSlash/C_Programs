#include<stdio.h>
int main(){
  int i,j;
  for(i=1;i<=20;i++){
    for(j=1;j<=10;j++){
      if((i*j)>=10){
        printf("%d  ",i*j);
      }else if((i*j)>=100){
      printf("%d ",i*j);
      }else{
        printf("%d   ",i*j);
      }
    }
    printf("\n");
  }
  return 0;
}