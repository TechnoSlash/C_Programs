#include<stdio.h>
#include<string.h>
int main(){
  char toUpper[100];
  int n,i;
  printf("Enter your character. \n");
  scanf("%s",toUpper);
  n=strlen(toUpper);
  for(i=0;i<n;i++){
    if(toUpper[i]>='a' && toUpper[i]<='z'){
      toUpper[i]-=32;
    }
  }
  printf("Uppercase= %s\n",toUpper);
  return 0;
}