//You are old man with condition gender male and
// age greater than or equal to 68
#include<stdio.h>
int main(){
  int age;
  char gender[10];
  printf("Enter your age and gender(male or female or other)");
  scanf("%d%s",&age,gender);
  if(age>=68){
    if(gender[0]=='m' ||gender[0]=='M'){
      printf("You are an old man\n");
    }else{
      printf("You are over 68 but you are not a male.\n");
    }
  }else{
      printf("You are less than 68.\n");
  }
  return 0;
}