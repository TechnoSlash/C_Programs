#include<stdio.h>
#include<string.h>
int main(){
  char toLower[100];
  int i=0,n;
  printf("Enter a word. \n");
  scanf("%s",toLower);
  n=strlen(toLower);
  for(i=0;i<n;i++){
    if(toLower[i]<='Z' && toLower[i]>='A')
    {
      toLower[i]+=32;
    }
  }
  printf("The lowercase character is %s.\n ",toLower);
  return 0;
}