#include <stdio.h>
int main(){
  int x;
  printf("\n");
  scanf("%d",&x);
 return 0;
}