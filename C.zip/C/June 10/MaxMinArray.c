//Write a program to find the largest and smallest elements in an array.
#include <stdio.h>
int main(){
  int n,i,max,min;
  printf("How many numbers do you want to compare?\n");
  scanf("%d",&n);
  int x[n];
  for(i=0;i<n;i++){
    printf("Enter the value of number %d.\n",i+1);
    scanf("%d",&x[i]);
  }
  max=x[0]; 
  min=x[0];
  for(i=0;i<n;i++){
  if(x[i]>max){
    max=x[i];
    }
  if(x[i]<min){
    min=x[i];
    }    
  }
  printf("The largest number is %d.\n",max);
  printf("The smallest number is %d.\n",min);
 return 0;
}