//Write a program to find the sum of all elements in an array.
#include <stdio.h>
int main(){
  int n;
  printf("How many numbers do you want to add?\n");
  scanf("%d",&n);
  int num[n],sum=0,i;
    for(i=0;i<n;i++){
    printf("Enter number %d.\n",i+1);
    scanf("%d",&num[i]);
  }
  for(i=0;i<n;i++){
    sum+=num[i];
  }
  printf("Sum= %d\n",sum);
 return 0;
}