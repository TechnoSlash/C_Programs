// WAP to read n numbers from user and sort and display them in ascending order
#include<stdio.h>
int main(){
  int n;
  printf("How many numbers do you want to input?\n");
  scanf("%d",&n);
  int num[n],i,j,temp;
  for(i=0;i<n;i++){
  printf("Enter number %d.\n",i+1);
  scanf("%d",&num[i]);
  }
  //Sorting
  for(i=0;i<n;i++){
    for(j=i+1;j<n;j++){
      if(num[i]>num[j]){
        temp=num[i];
        num[i]=num[j];
        num[j]=temp;
      }
    }
  }
    for(i=0;i<n;i++){
      printf("%d\t",num[i]);
    }
    return 0;
}