//Write a program to calculate the average of elements in an array.
#include <stdio.h>
int main(){
  int n;
  printf("How many numbers do you want to find average of?\n");
  scanf("%d",&n);
  float num[n],sum=0;
  int i;
    for(i=0;i<n;i++){
    printf("Enter number %d.\n",i+1);
    scanf("%f",&num[i]);
  }
  for(i=0;i<n;i++){
    sum+=num[i];
  }
  printf("Average= %f\n",sum/n);
 return 0;
}