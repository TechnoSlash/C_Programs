//WAP TO READ a number from user and check whether
// it is palindrome number or not.
#include<stdio.h>
#include<string.h>
int main(){
  int n,rev=0,rmd,num;
  printf("Enter a number.\n");
  scanf("%d",&n);
  num=n;
  while(n!=0){//4 2 1
    rmd=n%10;//1,2,4
    rev=rev*10+rmd;//124
    n=n/10; //789 78 7 0
  }
  if(rev==n){
      printf("Palindrome number.\n");
  }else{
    printf("Not a Palindrome number.\n");
  }
  return 0;
}