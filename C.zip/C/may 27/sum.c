//  WAP TO CALCULATE SUM OF REAL NUMBERS. The numbers should be 
// entered  until the user presses y
#include<stdio.h>
int main(){
  float num,sum=0;
  char ch;
  start:
  printf("Press y to continue and n to stop.\n");
  scanf(" %c",&ch);
  switch(ch){
    case 'n':
    break;
    case 'N':
    break;    
    default:
  printf("Enter your number.\n");
  scanf("%f",&num);
  sum+=num;
  goto start;
  }
  printf("Sum= %f.\n",sum);
  return 0;
}