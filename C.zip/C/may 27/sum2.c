//  WAP TO CALCULATE SUM OF REAL NUMBERS. The numbers should be 
// entered  until the user presses y
#include<stdio.h>
int main(){
  float num,sum=0;
  char ch;
  do{
  printf("Enter your number.\n");
  scanf("%f",&num);
  sum+=num;
  printf("Press y to continue and n to stop.\n");
  scanf(" %c",&ch);
}while(ch=='y');
    printf("Summation= %.2f\n",sum);
  
  return 0;
}