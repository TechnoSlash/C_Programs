// for loop- entry control loop.
// while loop- 
//do while loop