#include<stdio.h>
int main(){
  int num,prod=1,var;
  printf("Enter a number.\n");
  scanf("%d",&num);//9
  while(num!=0){
    var=num-1;//8,7
    prod*=num*var;//1*9*8, 9*8*7*
    num-=1;//8
  }
  printf("The factorial is %d.\n",prod);
  return 0;
}