//WAP to assign your name to a 
//variable and display it for ten times.
#include<stdio.h>
int main(){
  char name[]="Riwaj";
  for(int i=0;i<10;i++){
    printf("%s\n",name);
  }
  return 0;
}