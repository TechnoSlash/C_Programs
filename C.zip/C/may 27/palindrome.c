//WAP TO READ a number from user and check whether
// it is palindrome number or not.
#include<stdio.h>
#include<string.h>
int main(){
  int n,rev=0,rem,num;
  printf("Enter a number.\n");
  scanf("%d",&n);//say 421
  num=n;
  while(n>0){//4 2 1
    rem=n%10;//1,2,4
    rev=rev*10+rem;//124
    n/=10;
  }
  if(rev==num){
      printf("%d is a palindrome number.\n",num);
  }else{
    printf("%d is not a palindrome number.\n",num);
  }
  return 0;
}