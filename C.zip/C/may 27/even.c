//WAP to display even numbers that exist between 50 to 100
#include<stdio.h>
int main(){
  for(int i=50;i<=100;i=i+2){
    printf("%d\n",i);
  }
  return 0;
}