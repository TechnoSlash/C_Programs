#include<stdio.h>
int main(){
  int n,fac=1;
  printf("Enter a number.\n");
  scanf("%d",&n);
  for(int i=1;i<=n;i++){
    fac*=i;//8,7
  }
  printf("The factorial is %d.\n",fac);
  return 0;
}