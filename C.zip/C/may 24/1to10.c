#include<stdio.h>
int main(){
  int n=1;
  while(n<=10){
    printf("%d\n",n);
    n++;
  }
  return 0;
}