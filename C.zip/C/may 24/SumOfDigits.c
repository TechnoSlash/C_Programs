#include<stdio.h>
#include<string.h>
int main(){
  int n,sum=0,rem;
  printf("Enter a number.\n");
  scanf("%d",&n);//say 421
  while(n>0){//4 2 1
    rem=n%10;//1,2,4
    sum+=rem;//1+2+4
    n/=10;
  }
  printf("Sum of digits of the given number: %d\n",sum);
  return 0;
}