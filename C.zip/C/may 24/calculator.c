#include<stdio.h>
int main(){
  float num1,num2,output;
  char symbol;
  printf("Enter any two numbers.\n");
  scanf("%f%f",&num1,&num2);
  printf("Enter symbol(+,-,*,/).\n");
  scanf("%c",&symbol);
  switch(symbol){
    case '+':
    output=num1+num2;
    break;
    case '-':
    output=num1-num2;
    break;
    case '*':
    output=num1*num2;
    break;
    case '/':
    output=num1/num2;
    break;
    default:printf("Undefined symbol.\n"); 
    return 0;
  }
  printf("Output:%f.\n",output);
  return 0;
}