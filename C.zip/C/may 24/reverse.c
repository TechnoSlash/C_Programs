#include<stdio.h>
#include<string.h>
int main(){
  int n,rev=0,rem;
  printf("Enter a number.\n");
  scanf("%d",&n);//say 709
  while(n!=0){//7 0 9
    rem=n%10;//9,0,7
    rev=rev*10+rem;//9  90 907
    n/=10; // 7
  }
  printf("Reverse of the given number: %d\n",rev);
  return 0;
}