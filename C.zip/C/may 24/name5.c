#include<stdio.h>
int main(){
  int n=1;
  while(n<=5){
    printf("Name: Manisha\n");
    n++;
  }
  return 0;
}