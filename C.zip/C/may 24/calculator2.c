#include<stdio.h>
int main(){
  float a,b,output;
  char symbol;
  printf("Enter any two numbers.\n");
  scanf("%f%f",&a,&b);
  printf("Enter symbol(+,-,*,/).\n");
  scanf(" %c",&symbol);
  switch(symbol){
    case '+':printf("Sum:%f.\n",a+b);
    break;
    case '-':printf("Difference:%f.\n",a-b);
    break;
    case '*':printf("Product:%f.\n",a*b);
    break;
    case '/':printf("Division:%f.\n",a/b);
    break;
    default:printf("Undefined symbol.\n");
  }
  return 0;
}