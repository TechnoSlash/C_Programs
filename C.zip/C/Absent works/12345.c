#include<stdio.h>
int main(){
  int i,j;
  for(j=1;j<=5;j++){
  for(i=j;i<=5;i++){
    printf("%d\t",i);
  }  
  printf("\n");
  }

}