
#include <stdio.h>
int main(){
  int n,i,j,large,smallest,temp;
  printf("How many numbers do you want to compare with?\n");
  scanf("%d",&n);//3
  int numbers[n];
  for(i=0;i<n;i++){
  printf("Enter number %d.\n",i+1); //5 6 7 
  scanf("%d",&numbers[i]);
  }
large=num[0];// initializing large= first number of array for(i=1;i<n;i++)
{
if(num[i]>=large)
large=num[i]; }
printf("largest number: %d",large); 
return 0;
}
  // for(i=0;i<n,i++){
  //   for(j=i+1;j<n;j++){
  //         if(numbers[i]>numbers[j]){//5>6
  //           smallest=numbers[i];
  //         }else{
  //           largest=numbers[i]
  //         }
  //   }
  // }
//   return 0; 
// }

// large=num[0];// initializing large= first number of array for(i=1;i<n;i++)
// {
// if(num[i]>=large)
// large=num[i]; }
// printf("largest number: %d",large); return 0;
// }