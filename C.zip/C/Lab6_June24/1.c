//1) Declare an integer array naming box1 of size 5 and initialize the array box1 with numbers 0, 
// 11, 22, 33, 44 and declare another float array box2, which will take user input. Display the 
// contents of both arrays simultaneously.
#include<stdio.h>
int main(){
  int box1[5]={0,11,22,33,44};
  float box2[5];
  for(int i=0;i<5;i++){
    printf("Enter the value %d of box 2.\n",i+1);
    scanf("%f",&box2[i]);
  }
  printf("The values of box1 is \n");
  for(int i=0;i<5;i++){
  printf("%d\t",box1[i]);
  }
  printf("The values of box2 is \n");
  for(int i=0;i<5;i++){
  printf("%f\t",box2[i]);
  }
  return 0;
}