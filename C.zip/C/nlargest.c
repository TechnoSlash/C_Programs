
#include <stdio.h>
int main(){
  int n,i,j,large,smallest,temp;
  printf("How many numbers do you want to compare with?\n");
  scanf("%d",&n);//3
  int numbers[n];
  for(i=0;i<n;i++){
  printf("Enter number %d.\n",i+1); //5 6 7 
  scanf("%d",&numbers[i]);
  }
  large=numbers[0];//5 // initializing large= first number of array 
  for(i=1;i<n;i++){
    if(n[i]>=large)
    large=n[i]; }
    printf("largest number: %d",large); 
    return 0;
    }