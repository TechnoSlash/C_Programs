#include<stdio.h>
#define PI 3.14159
int main()
{
  float R,Area;
  printf("Enter the radius: ");
  scanf("%f",&R);
  Area=PI*R*R;
  printf("The area = %f\n",Area);
  return 0;
}