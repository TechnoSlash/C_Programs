#include<stdio.h>
int main(void)
{
  int a,b,prod;
    printf("Enter any two numbers: ");
  scanf("%d%d",&a,&b);
  prod=a*b;
  printf("%d * %d= %d \n",a,b,prod);
}