#include<stdio.h>
int main()
{
  float I,P,T,R;
 printf("Enter your Principle amount: ");
  scanf("%f",&P); 
  printf("Enter your rate: ");
  scanf("%f",&R);
  printf("Enter your time: ");
  scanf("%f",&T);
  I=P*T*R/100;
  printf("Interest= %f \n",I);
  return 0;
}