#include<stdio.h>
int main()
{
  float CP=990,SP=1220,profit=SP-CP,profit_Percentage=(profit/CP)*100;
  printf("Profit= %f \n",profit);
  printf("Profit Percentage= %f \n",profit_Percentage);
  return 0;
}