#include<stdio.h>
#include<stdlib.h>
int main(){
  int a=10,b=5,c=20,y=100;
  a--;//a=9
  y+=a+b+c;//y=9+5+20+100=134  += is a short hand operator
  printf("y=%d\n",y);
   system("clear"); // clears the screen 
   return 0;
}