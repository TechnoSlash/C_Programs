/* 3. wap to convert number of days to years, months and days
*/
#include<stdio.h>
int main()
{
  int days,months,year;
  printf("Enter the number of days: ");
  scanf("%d",&days);
    year=days/365;
    days=days%365;
    months=(days)/30;
    days=days%30;
 printf("%d year %d month and %d days \n",year,months,days);
 return 0;
}