#include<stdio.h>
// #include<stdlib.h>
int main(){
  printf("No of bytes for character=%lu\n",sizeof(char));
  printf("No of bytes for short integer=%lu\n",sizeof(short int));  
  printf("No of bytes for integer=%lu\n",sizeof(int));
  printf("No of bytes for long integer=%lu\n",sizeof(long int));
  printf("No of bytes for float=%lu\n",sizeof(float));
  printf("No of bytes for double=%lu\n",sizeof(double));
  printf("No of bytes for long double=%lu\n",sizeof(long double));
  getchar();
  return 0;
}