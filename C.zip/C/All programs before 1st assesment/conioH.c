#include <stdio.h>
#include <stdlib.h>

int main()
{
    char c;
    printf("Enter a character: ");
    c = getchar();
    printf("You entered: %c\n", c);
    printf("Press any key to clear the screen...");
    getchar(); // clears the newline character
    getchar(); // waits for the user to press a key
    system("clear"); // clears the screen
    return 0;
}
