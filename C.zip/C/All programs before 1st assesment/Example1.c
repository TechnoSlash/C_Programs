#include <stdio.h> //header files
#include <stdlib.h>
int main()  //main function
{
  system("clear"); // clears the screen
  printf("This is my first assignment in C programming");
  getchar(); // clears the newline character
  getchar(); // waits for the user to press a key
  return 0;
}