#include<stdio.h>
#include<stdlib.h>
int main(){
  int a=5,b=10,c=-6,x1,x2,x3,x4,x5;
  x1=a>b && a<c;// 5>10 false and 5<6 false                             FALSE
  x2=a<b && a>c;//5<10 true and 5> -6 true                              TRUE
  x3=a==c || b>a;//FALSE OR TRUE                                        TRUE
  x4=b>15 && c<0 || a>0;//(FALSE AND TRUE) OR TRUE                      TRUE
  x5=(a/2==0 && b/2!=0) || c<0;// (FALSE AND TRUE)--> FALSE || TRUE --> TRUE
  printf("x1=%d\tx2=%d\tx3=%d\tx4=%d\tx5=%d",x1,x2,x3,x4,x5);//01111
  // getchar(); // clears the newline character
  getchar(); // waits for the user to press a key
  // system("clear"); // clears the screen
  return 0;
}