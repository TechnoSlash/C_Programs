#include<stdio.h>
int main()
{
  float l,b,h,Volume;
  printf("Enter your length,Breadth and Height: ");
  scanf("%f%f%f",&l,&b,&h);
  Volume=l*b*h;
  printf("Your Volume= %f \n",Volume);
  return 0;
}