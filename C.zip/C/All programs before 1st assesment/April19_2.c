#include<stdio.h>
int main(){
  char string[50];
  int test;
  float testf;
  char str[]="CUTE BABY";
  // scanf("%[ABCD]",string);
  // scanf("%[A-Z]",string);
  // scanf("%[^A-Za-z]",string);
  // scanf("%[A-Za-z]",string);
  // scanf("%[^\n]",string);
  // scanf("%[^ ]",string);
  // scanf("%s",string);
  // scanf("%3d",&test);
  // scanf("%f",&testf);
  // printf("Hello%8.4f",testf);
  printf("%-17.8s",str);
  return 0;
}