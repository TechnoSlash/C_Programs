//Y1=x5+10x4+8x3+4x+2 Y2= (ax+b)/c+ ax3-2b
#include<stdio.h>
#include<math.h>
int main(){
  int x,a,b,c;
  float y1,y2;
  printf("Enter x.\n");
  scanf("%d",&x);
  printf("Enter a.\n");
  scanf("%d",&a);
  printf("Enter b.\n");
  scanf("%d",&b);
  printf("Enter c.\n");
  scanf("%d",&c);
  y1=pow(x,5)+10*pow(x,4)+8*pow(x,3)+4*x+2;
  y2=((a*x+b)/c)+a*pow(x,3)-2*b;
  printf("y1=%f\ty2=%f\n",y1,y2);
}