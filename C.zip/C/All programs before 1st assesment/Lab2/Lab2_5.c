//5. WAP to convert lower character given by user to uppercase.
#include<stdio.h>
#include<string.h> 
int main(){
  char toUppercase[100];
  printf("Enter a string: ");
  scanf("%s",toUppercase);
  int n=strlen(toUppercase);
  for(int i=0;i<n;i++){
    if (toUppercase[i]<='z' && toUppercase[i]>='a'){//Does not 
      toUppercase[i]=toUppercase[i]-32;//work when we use
    }                                  //double quote. i.e. "z"
  }
  printf("Uppercase= %s\n",toUppercase);
  return 0;
}