//WAP to swap the values of two variables given by the user
#include <stdio.h>
int main() {
  int a,b,temp;
  printf("Enter a and b:\n");
  scanf("%d%d",&a,&b);
  printf("Before changing them.\n");
  printf("a=%d\tb=%d\n",a,b);
  temp = a;//temp=5
  a = b;//a=7
  b = temp;//b=5
  printf("After changing them.\n");
  printf("a=%d\tb=%d\n",a,b);
   return 0;
}

