// 4. WAP to separate the user given three digits number and display
//  each separated digit in a new line.
#include<stdio.h>
int main(){
  int number,ones,tens,hundreds;
  printf("Enter a 3 digit number: ");
  scanf("%3d",&number);
    ones=number%10;
    tens=(number%100)/10;
    hundreds=(number%1000)/100;
    printf("ones: %d\ntens: %d\nHundreds: %d\n",ones,tens,hundreds);
    return 0;
}


