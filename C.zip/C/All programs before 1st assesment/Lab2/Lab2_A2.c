#include<stdio.h>
#include<math.h>
int main(){
  float a,p,n,r;
  printf("Enter P,N and R.\n");
  scanf("%f%f%f",&p,&n,&r);
  a=p*pow((1+r),n);
  printf("A: %f\n",a);
  return 0;
}
