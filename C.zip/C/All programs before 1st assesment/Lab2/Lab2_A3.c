// 3. WAP to find the maximum between two numbers 
// using conditional operators.
#include<stdio.h>
int main(){
  int a,b;
  printf("Enter two numbers.\n");
  scanf("%d%d",&a,&b);
  a>b?printf("First number is greater.\n"):printf("Second number is greater\n");
  return 0;
}