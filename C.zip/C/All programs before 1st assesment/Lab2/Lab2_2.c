//2. To write a program to read personal information and display 
//it on the screen
#include <stdio.h>
int main() {
  char name[25],addr[25];
  int roll;
  printf("Input name: ");
  scanf("%s",name);
  printf("Input address: ");
  scanf("%s",addr);
  printf("Enter your roll: ");
  scanf("%d",&roll);
  printf("name: %s\naddress: %s\nroll-no: %d\n",name,addr,roll);
 return 0;
}