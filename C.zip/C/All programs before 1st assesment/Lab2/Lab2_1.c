//1.To write a program to read a character from keyboard and display it.
#include <stdio.h>
int main() {
  char character;
  printf("Input character:");
  scanf("%c",&character);
  printf("Character: %c\n",character);
 return 0;
}