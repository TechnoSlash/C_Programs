// 4. WAP to separate the user given three digits number and display
//  each separated digit in a new line.
#include<stdio.h>
int onePlace(int number);
int tenPlace(int number);
int hundredPlace(int number);
int main(){
  int number,one,ten,hundred;
  printf("Enter a 3 digit number: ");
  scanf("%d",&number);
  if(number<1000 && number>99){
    one=onePlace(number);
    ten=tenPlace(number);
    hundred=hundredPlace(number);
      printf("ones: %d\ntens: %d\nHundreds: %d\n",one,ten,hundred);
  }else{
    printf("The number was not of 3 digits.\n");
    // a syntax to convert any number into 3 digits
    // one=onePlace(number);
    // ten=tenPlace(number);
    // hundred=hundredPlace(number);
  }
  return 0;
}
  int onePlace(number){
        int ones;
    ones=number%10;
    return ones;
  }
  int tenPlace(number){
        int tens;
    tens=number%100;
    tens/=10;
    return tens;
  }
  int hundredPlace(number){
        int hundreds;
    hundreds=number%1000;
    hundreds/=100;
    return hundreds;
  }  