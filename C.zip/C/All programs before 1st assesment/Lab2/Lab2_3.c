/*3. WAP to take information of a student as input and display
them suitably. Information includes name, roll no, age, phone
 number and email address.*/
 #include <stdio.h>
int main() {
  char name[10],phone[10],email[40];
  int roll,age;
  printf("Input name: ");
  scanf("%s",name);
  printf("Enter your roll: ");
  scanf("%d",&roll);
  printf("Enter your age: ");
  scanf("%d",&age);
  printf("Input phone number: ");
  scanf("%s",phone);
  printf("Input e-mail: ");
  scanf("%s",email);
  printf("name:%s\nroll no:%d\nage:%d\nphone-number:%s\nemail:%s\n",name,roll,age,phone,email);
 return 0;
}