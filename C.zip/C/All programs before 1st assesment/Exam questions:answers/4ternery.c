#include<stdio.h>
int main(){
  int a,b,c;
  printf("Input three numbers.\n");
  scanf("%d%d%d",&a,&b,&c);
  a<b?(a<c?printf("first number"):printf("Third number")):(b<c?printf("Second number"):printf("Third number"));
  printf(" is the smallest number.\n");
  return 0;
}