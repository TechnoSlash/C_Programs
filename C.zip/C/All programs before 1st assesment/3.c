#include<stdio.h>
int main()
{
  float inch,meter;
  printf("Enter your length in inch: ");
  scanf("%f",&inch);
  meter=inch*0.0254;
  printf("Enter your length in meter= %f \n",meter);
  return 0;
}