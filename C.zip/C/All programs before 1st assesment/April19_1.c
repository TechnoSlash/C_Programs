#include<stdio.h>
int main(){
  puts("*****");
  putch('\n');
  puts(" ****");
  putch('\n');
  puts("  ***");
  putch('\n');
  puts("   **");
  putch('\n');
  puts("    *");
  return 0;
}