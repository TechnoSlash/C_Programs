#include<stdio.h>
int main(){
  int a=3; 
  float b=3;
  char c='p';
  a*=2.3;
  b*=2.3;
  printf("a=%d\nb=%f\nb=%.2f\nc=%c\nASCII c=%d\tchar=%c",a,b,b,c,c,c);
  getchar();
  return 0;
}