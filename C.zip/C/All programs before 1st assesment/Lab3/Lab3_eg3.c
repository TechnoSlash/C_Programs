#include <stdio.h>
int main() {
  int a;// simple integer type 
  long int b; // long integer type 
  short int c; // short integer type
  unsigned int d;// unsigned integer type 
  char e;// character type
  float f;// floating point type
  double g;// double precision floating point
  char str[]="NEPAL";
a = 1023; 
b = 2222; 
c = 123; 
d = 1234; 
e = 'X';
f = 3.14159;
g = 3.1415926535898;
  printf("a = %d\n",a);
  printf("a = %o\n",a);
  printf("a = %x\n",a);
  printf("b = %ld\n",b);
  printf("c = %d\n",c);
  printf("d = %u\n",d);
  printf("e = %c\n",e);
  printf("f = %f\n",f); 
  printf("g = %f\n",g); 
  printf("\n");
  printf("a = %d\n",a);
  printf("a = %7d\n",a);
  printf("a = %-7d\n",a);
printf("\n");
printf("f = %f\n",f);
printf("f = %12f\n",f);
printf("f = %12.3f\n",f); // use 3 decimal places 
printf("f = %12.5f\n",f); // use 5 decimal places 
printf("f = %-12.5f\n",f); // left justify in field
printf("e=%10c\n",e);
printf("String= %s\n",str);
printf("String= %.3s\n",str);
printf("String= %10.3s\n",str);
  getchar();
  return 0;
}