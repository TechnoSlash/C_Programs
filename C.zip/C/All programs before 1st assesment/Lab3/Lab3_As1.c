// WAP to read marks of the student in a subject. The input marks should be less than 100 (i.e. only
// two digits). If input marks has more than two digits, ignore the digits after second digit.
#include<stdio.h>
int main(){
  int a;
  printf("Enter your marks.\n");
  scanf("%2d",&a);
  printf("Marks= %d\n",a);
  return 0;
}