//3. WAP to find maximum between two numbers using conditional operators.
#include<stdio.h>
int main(){
  int a,b;
  printf("Enter a and b.\n");
  scanf("%d%d",&a,&b);
  a>b?printf("a is maximum\n"):printf("b is maximum\n");
}