#include<stdio.h>
#include<stdlib.h>
int main(){
  char str[20];
  int a,b;
  system("clear"); // clears the screen
  printf("Enter two numbers.\n");
  scanf("%2d%3d",&a,&b);
  printf("\n a=%d and b=%d",a,b);
  printf("Enter string.\n");
  scanf(" %[A-Z]",str);
  printf("Characters in uppercase=%s\n",str);
  getchar();
  return 0;
}