//5.WAP to reverse the four digit number.
#include<stdio.h>
int main(){
  int a,ones,tens,hundreds,thousands,rev;
  printf("Enter a 4 digit number.\n");
  scanf("%4d",&a);// say 2345
  ones=a/1000;//2
  tens=(a/100-ones*10);//23-20=3
  hundreds=a/10-ones*100-tens*10;//234-200-30=4
  thousands=a-ones*1000-tens*100-hundreds*10;// 2345-2000-300-40=5
  rev=thousands*1000+hundreds*100+tens*10+ones;// 5432
  printf("The reverse of the number is %d\n",rev);
  return 0;
}