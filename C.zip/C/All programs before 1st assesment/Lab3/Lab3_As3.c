// WAP to read and display only numbers from the user. The program should not read any other characters.
#include <stdio.h>
int main() {
  char num[20];
  printf("Input number:");
  scanf ("%[^A-Za-z]",num);
  printf("Number: %s\n",num);
 return 0;
}