//WAP to take distance input in km and convert it into meter, feet
//, inch and centimeter and display each of them.
#include<stdio.h>
int main(){
  float kilometer,meter,cm,inch,feet;
  printf("Enter distance in km.\n");
  scanf("%f",&kilometer);// say 10 km
  meter=kilometer*1000;
  cm=meter*100;
  inch=cm/2.54;
  feet=inch/12;
  printf("meter=%.2f m\ncentimeter=%.2f cm\ninch=%.2f inch\nfeet=%.2f feet\n",meter,cm,inch,feet);
}