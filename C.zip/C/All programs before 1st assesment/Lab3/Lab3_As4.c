// WAP that will allow the contents of text read from keyboard to be displayed in the following ways
// a.Entirely on one line
// b.Only the first 8 character
// c.The first eight character proceeded by the five blanks. 
// d.The first eight character followed by the five blanks
#include <stdio.h>
int main() {
  char line[100];
  printf("Input word:");
  scanf ("%[^\n]",line);
  printf("a)One line: %s\n",line);
  printf("b)First 8 characters: %.8s\n",line);
  printf("c)First 8 characters preceeded by 5 blanks: %13.8s\n",line);
  printf("d)First 8 characters followed by 5 blanks: %-13.8s\n",line);
 return 0;
}