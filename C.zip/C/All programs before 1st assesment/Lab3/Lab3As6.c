//WAP to calculate the roots of quadratic equation [ax2+bx+c=0]. Ask the value of a, b and c with the user.
#include<stdio.h>
#include<math.h>
int main(){
  float a,b,c,root1,root2,B;
  printf("Enter a,b,c.\n");
  scanf("%f%f%f",&a,&b,&c);
  B=pow(b,2);
  root1=(-b+(pow((B-4*a*c),0.5)))/(2*a);
  root2=(-b-(pow((B-4*a*c),0.5)))/(2*a);
  printf("Root1= %f\n",root1);
  printf("Root2= %f\n",root2);
}