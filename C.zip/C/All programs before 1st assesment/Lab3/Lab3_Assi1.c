//Ramesh’s basic salary is input through the keyboard. His dearness allowance is 
//40% of basic salary and house rent allowance is 20% of basic salary. WAP to calculate his gross salary.
#include<stdio.h>
int main(){
  float salary,grossSalary;
  printf("Enter Ramesh's salary in rs.\n");
  scanf("%f",&salary);
  grossSalary=salary*(1.6);
  printf("The gross salary of ramesh is Rs %.2f\n",grossSalary);
}