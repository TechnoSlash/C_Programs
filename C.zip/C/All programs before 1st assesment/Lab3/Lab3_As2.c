#include <stdio.h>
int main() {
  char line[200];
  printf("Input word:");
  scanf ("%[^\n]",line);
  printf("word: %s\n",line);
 return 0;
}

