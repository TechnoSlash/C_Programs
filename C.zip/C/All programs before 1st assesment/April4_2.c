//WAP to read the coefficients of a quadratic eqn and find real roots.
#include<stdio.h>
#include<math.h>
int main()
{
  float a,b,c,theta,B,AC,root,root1,root2;
  printf("Enter a,b and c of a quadratic equation(ax*x+bx+c): ");
  scanf("%f%f%f",&a,&b,&c);
  B=b*b;
  AC=4*a*c;

  if(B>AC)
  {
    root=pow(B-AC,0.5);
    root1=(-b+root)/(2*a);
    root2=(-b-root)/(2*a);
    printf("First root is %f ",root1);
    printf("Second root is %f ",root2);
  }
  else if (B==AC)
  {
    root1=(-b)/(2*a);
    printf("Only one root is available which is equal to %f ",root1);
  }
  else
  {
    printf("The roots are imaginary");
  }
  return 0;
}