// test
#include<stdio.h>
int main()
{
  int a=15,b=6;
  printf("%d\n",a>>2);
  return 0;
}