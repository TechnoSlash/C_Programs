#include<stdio.h>
#define PI 3.14159
int main()
{
  float R1,R2,Area,Area1,Area2;
  printf("Enter the bigger radius: ");
  scanf("%f",&R1);
  printf("Enter the smaller radius: ");
  scanf("%f",&R2);
  Area1=PI*R1*R1;
  Area2=PI*R2*R2;
  Area=Area1-Area2;
  printf("The area between two concentric circles= %f\n",Area);
  return 0;
}