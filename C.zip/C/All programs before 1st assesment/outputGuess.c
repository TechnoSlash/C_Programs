#include<stdio.h>
int main()
{
  int x,y;
  x=10;y=20;
  printf("%d\n",x++);//10
  printf("%d\n",x);//11
  printf("%d\t%d\n",y--,y);//20  19
  printf("%d\n",--y);//18
  printf("%d\n",y);//18
  printf("%d\n",y++);//18
  printf("%d\n",y);//19
  //x=11 y=19
  return 0;
}