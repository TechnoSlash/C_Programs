// Run the following program and observe the output for different inputs:
# include<stdio.h>
int main()
{
int x;
printf("Enter any number:"); 
scanf("%d", &x);
if(x>5)
printf("%d is greater than 5\n",x); 
if(x>10)
printf("%d is greater than 10\n",x); 
if(x<100)
printf("%d” is less than 100\n",x); 
getchar();
}