//Write program to check whether the given number is even or odd.
#include<stdio.h>
int main(){
  int num;
  printf("Enter a number.\n");
  scanf("%d",&num);
  num%2==0?printf("It is even\n"):printf("It is odd\n");
  return 0;
}