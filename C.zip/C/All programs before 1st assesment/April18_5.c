#include<stdio.h>
#include<stdlib.h>
int main(){
  char ch;
  system("clear"); // clears the screen
  ch=getchar();
  putchar('\n');
  putchar('*');
  putchar('\n');
  putchar(ch);
  return 0;
}