#include<stdio.h>
int main()
{
  float inch,meter;
  printf("Enter your temperature in Fahrenheit: ");
  scanf("%f",&inch);
  meter=(inch-32)/1.8;
  printf("Enter your Temperature in celcius= %f \n",meter);
  return 0;
}