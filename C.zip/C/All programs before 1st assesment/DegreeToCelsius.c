#include<stdio.h>
int main()
{
  float Fahrenheit,Celsius;
  printf("Enter your temperature in Fahrenheit: ");
  scanf("%f",&Fahrenheit);
  Celsius=(Fahrenheit-32)/1.8;
  printf("Your Temperature in celsius= %f \n",Celsius);
  return 0;
}

