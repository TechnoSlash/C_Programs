//WAP to convert the cartesian coordinate to the polar form
// (x,y)=(r,Theta) r= sqr(x*x+y*y,1/2) theta=arctan(y/x)/Pi
#include<stdio.h>
#define PI 3.14159
#include<math.h>
int main()
{
  float x,y,r,theta;
  printf("Enter x and y.\n");
  scanf("%f%f",&x,&y);
  r=pow(x*x+y*y,1/2);
  theta=atan(y/x);
  theta=180*theta/PI;
  printf("r= %f\n",r);
  printf("Theta= %f\n",theta);
  return 0;
}
