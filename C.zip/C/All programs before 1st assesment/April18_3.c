#include<stdio.h>
#include<stdlib.h>
int main(){
  int a=60,b=15;//a=111100 b=1111
  printf("%d\n",a&b);//111100
  //                  &001111
  //                   001100   12
  printf("%d\n",a|b);//111100
  //                  |001111
  //                   111111   63
  printf("%d\n",a^b);//111100
  //                  ^001111
  //                   110011   51
  printf("%d\n",a>>2);//111100 last 2 hatyo
  //                    001111  15
  printf("%d\n",b<<3);//1111 last 3 add bho
  //                 1111000    120
  getchar();
  return 0;
}