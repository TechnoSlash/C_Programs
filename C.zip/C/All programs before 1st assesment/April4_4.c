//.WAP to convert seconds into hours, minutes and second
#include<stdio.h>
#include<math.h>
int main()
{
  int hour,minute,second;
  printf("Enter the time in seconds: ");
  scanf("%d",&second);
  minute=second/60;
  hour=minute/60;
  second=second%60;
  minute=minute%60;
 printf("%d hours %d minute and %d seconds \n",hour,minute,second);
 return 0;
}