#include<stdio.h>
int main()
{
  char operator;
  printf("Enter your operator: ");
  scanf("%c",&operator);
  if (operator='+')
  {
  printf("It was plus");
  }
  else if (operator='-')
  {
  printf("It was minus");
  }
  else
  {
  printf("It was minus");
  }
  
  return 0;
}