#include<stdio.h>
int main(){
  int flag=1,i,j;
  for(i=2;i<101;i++){
    flag=1;
    for(j=2;j<=i/2;j++){
      if(i%j==0){
        flag=0;
        break;
      }
  }
  if(flag==1){
    printf("%d \t",i);
  }
  }
  return 0;
}
