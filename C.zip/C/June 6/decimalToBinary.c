#include<stdio.h>
#include<math.h>
int main(){
  int num,rmd,sum=0,n=1;
  printf("Enter your decimal number.\n");
  scanf("%d",&num);// 10
  while(num>0){//10 5 2 1
    rmd=num%2;//0 1 0 1
    sum=sum+rmd*pow(10,n);//0 10 010 1010
    n++;
    num/=2;//5 2 1
  }
  printf("The number in binary is %d\n",sum);//100
  return 0;
}