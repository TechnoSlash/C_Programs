#include<stdio.h>
#include<math.h>
int main(){
  long int n,b=0,m=1,rmd;
  printf("Enter your decimal number.\n");
  scanf("%ld",&n);// 10
  do{
    rmd=n%2;
    b=b+rmd*m;
    n=n/2;
    m=m*10;
  }while(n>0);
  printf("The number in binary is %ld\n",b);//1010
  return 0;
}