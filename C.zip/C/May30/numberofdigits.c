//WAP to enter a number. Count the number of digits as well 
//as calculate the sum of digits and display it
#include<stdio.h>
int main(){
  long int num,n,rem,sum=0;// int ko 2^15 + 2^15 -1 or 2^16-1
  // long int supports upto 10 digits
  int i,countD=0;
  printf("Enter a number.\n");
  scanf("%ld",&num); //767
  do{
    rem=num%10;//7  6  7
    sum+=rem;//7 7+6  11+7
    countD+=1;
    num=num/10;
  }while(num>0);
  printf("The number of digits= %d\n",countD);
  printf("Sum of each of digits= %ld\n",sum);

} 