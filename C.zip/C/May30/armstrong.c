#include<stdio.h>
#include<math.h>
int main(){
  long int num,n,rem,sum=0;// int ko 2^15 + 2^15 -1 or 2^16-1
  // long int supports upto 10 digits
  int i,countD=0;
  printf("Enter a number.\n");
  scanf("%ld",&num); 
  n=num;
  do{
    rem=num%10;
    sum+=pow(rem,3);
    countD+=1;
    num=num/10;
  }while(num>0);
  printf("The number of digits= %d\n",countD);
  printf("Sum of cubes= %ld\n",sum);
  if(n==sum){
    printf("%ld is an armstrong number\n",sum);
  }
  return 0;
} 