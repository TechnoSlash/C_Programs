#include<stdio.h>
int main(){
  float m,prod=1;
  int n;
  printf("Enter the value of base m.\n");
  scanf("%f",&m);
  printf("Enter the value of power n.\n");
  scanf("%d",&n);
  if(n>0){
  for(int i=1;i<=n;i++){
    prod=prod*m;
  }
  }
  else if(n<0){
  for(int i=-1;i>=n;i--){
  prod=prod*1/m;
  printf("%f\n",prod);
  }
  }
  printf("The value is %f.\n",prod);
  return 0;
}