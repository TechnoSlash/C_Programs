//Fibonacci series upto n term
// 0 1 1 2 3 5 8 ... nth term
#include<stdio.h>
int main(){
  int a=0,b=1,c,n;
  printf("How many terms do you need?");
  scanf("%d",&n);
  switch(n)
  {
  case 1:
  printf("%d\t",a);
  break;
  case 2:
  printf("%d\t",a);
  printf("%d\t",b);
  break;
  default:
  printf("%d\t",a);
  printf("%d\t",b);  
  for(int i=0;i<n-2;i++){
    c=a+b;
    printf("%d\t",c);
    a=b;
    b=c;
  }
  break;
  }
  return 0;
}