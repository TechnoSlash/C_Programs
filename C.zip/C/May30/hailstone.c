//WAP to displaay a Hailstone series upto nth term 
//where 1st number is given by user
// 17 odd=> num=num*3+1
// 52 even=> num=num/2
#include<stdio.h>
int main(){
  int n,terms;
  printf("Write first number of hailstone series.\n");
  scanf("%d",&n);
  printf("How many terms do you want? \n");
  scanf("%d",&terms);
  printf("%d\t",n);
  for(int i=1;i<=terms-1;i++){
    if(n%2==0){
      n=n/2;
    }else{
      n=n*3+1;
    }
    printf("%d\t",n);
  }
  return 0;
}